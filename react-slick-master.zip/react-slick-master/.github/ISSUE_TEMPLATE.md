<!-- Love react-slick? Please consider supporting our collective:
👉  https://opencollective.com/react-slick/donate -->

### Guidelines for posting a new issue

* Please replicate your issue with this [CodeSandBox](https://codesandbox.io/s/ppwkk5l6xx) and provide a link to it along with the issue description
